require 'spec_helper'

def generate_jura_email(user_type = :student)
  return 'aut_' + user_type.to_s + '_'  + SecureRandom.random_number(9999999999).to_s + '@mailinator.com'
end

def generate_new_account_data(predefined_data, user_type)
  new_account_data = predefined_data.clone
  new_account_data[:email_address] = generate_jura_email(user_type)
  new_account_data[:first_name] = FFaker::Name.first_name
  new_account_data[:last_name] = FFaker::Name.last_name
  case user_type
    when :student then new_account_data[:registration_code] = $env_test_data[:registration_codes][:student]
    when :teacher then new_account_data[:registration_code] = $env_test_data[:registration_codes][:teacher]
    else return
  end

  new_account_data
end


def generate_new_class_data
  class_data = {:class_name => 'Auto' + SecureRandom.random_number(99999).to_s,
                :description => 'edit class',
                :course_name => $env_test_data[:course_data][:course_name]}
  return class_data
end

def select_day(page, day)
  page.day_of_birth.click
  page.days.each do |d|
    d.click if d.text.eql?(day.to_s)
  end
end

def select_month(page, month)
  page.month_of_birth.click
  page.months.each do |m|
    m.click if m.text.eql?(month)
  end
end

def select_year(page, year)
  page.year_of_birth.click
  page.years.each do |y|
    y.click if y.text.eql?(year.to_s)
  end
end

def select_date_of_birth_on(page, day, month, year)
  select_day(page, day)
  select_month(page, month)
  select_year(page, year)
  sleep(2)
end

def select_option_from_menu_on(page, option)
  page.header.menu_button.click
  sleep(1)
  page.header.courses_button.click if page.header.courses_in_menu.first.displayed?

  case option.to_sym
    when :classes then page.header.classes_button.click
    when :class_management then page.header.class_management_button.click
    when :courses then page.header.courses_button.click
    when :marking then page.header.marking_button.click
    when :messages then page.header.messages_button.click
    else return
  end
end

def select_class_from_menu_on(page, class_name)
  select_option_from_menu_on(page, :classes)
  sleep(1)
  page.header.classes_in_menu.each { |c| if c.text.include?(class_name) ; c.click ; break ; end }
  sleep(3)
end

def select_course_from_menu_on(page, course_name)
  select_option_from_menu_on(page, :courses)
  sleep(1)
  page.header.courses_in_menu.each { |c| if c.text.downcase.eql?(course_name.downcase) ; c.click ; break ; end }
  sleep(3)
end

def find_course_on_page(page,course_name)
  until page.course_name.downcase.include? (course_name.downcase) do
    sleep(1)
    page.next_course_button.click
  end
end

def pick_course(page, course_name)
  if page.is_a? EditClassPage
    page.courses.each { |c| if c.text.include?(course_name) ; c.click ; break ; end }
  end
  sleep(1)
end

def pick_class(page, course_name)
  if page.is_a? MessagesPage
    sleep(2)
    page.classes_list.each { |c| if c.text.include?(course_name) ; c.click ; break ; end }
  end
  sleep(1)
end

def select_message(page, message_subject)
  if page.is_a? DashboardPage
    page.messages_list_as_student.each { |c| if c.text.include?(message_subject) ; c.click ; break ; end }
  end
  sleep(1)
end

def get_course_code_for_a_new_class(class_data, teacher_data)
  login_to_Jura(teacher_data[:user_name], teacher_data[:password])
  dashboard_page = DashboardPage.new(@browser)
  sleep(2)
  add_new_class(dashboard_page, class_data, :percentage)
  sleep(3)
  course_code = get_course_code(class_data[:class_name])
  dashboard_page.header.log_out_button.click
  sleep(1)
  course_code
end

def select_unit_from_course_page(unit_name)
  course_page = CoursePage.new(@browser)
  course_page.unit_names.each_with_index { |n, i| if n.text.downcase == unit_name.downcase ; course_page.units[i].click ; break ; end }
  sleep(2)
end

def select_section_from_unit_page(section_name)
  unit_page = UnitPage.new(@browser)
  loop do
    unit_page.section_names.each_with_index do |n, i|
      if n.text.downcase.include?(section_name.downcase)
        unit_page.sections[i].click
        sleep(2)
        return
      end
    end
    unit_page.slide_right_button.click
    sleep(1)
  end
end

def select_activity_from_unit_page(index)
  index = index.to_i
  unit_page = UnitPage.new(@browser)
  unit_page.activities[index - 1].click
  sleep(2)
end