def wait_for_page_to_load
  wait = Selenium::WebDriver::Wait.new(:timeout => 10)
  wait.until { @browser.execute_script("return document.readyState;") == "complete" }
end

def wait_for_element(time_out = 30)
  Selenium::WebDriver::Wait.new(:timeout => time_out).until { yield }
end

def wait_for_mailinator_inbox
  wait_for_element(10) { @browser.find_element(:css, '#InboxCtrl').displayed? }
end

def wait_for_email_frame
  wait_for_element { @browser.find_element(:css, 'iframe[name = rendermail]').displayed? }
end

def wait_for_profile_save_success_flash
  wait_for_element { @browser.find_element(:xpath, '//section/div/div[3]').displayed? }
end