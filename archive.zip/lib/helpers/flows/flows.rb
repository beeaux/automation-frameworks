require 'spec_helper'
require 'date'

def login_to_Jura(user_name, user_password)
  go_to_Jura

  home_page = HomePage.new(@browser)
  home_page.user_name.send_keys(user_name)
  home_page.user_password.send_keys(user_password)
  home_page.login_button.click
  sleep(5)
end

def go_to_Jura
  @browser.navigate.to($env_test_data[:environment_urls][:site][:base_uri])
  sleep(2)
end

def go_to_registration_page
  home_page = HomePage.new(@browser)
  home_page.register_button.click
  sleep(2)
end

def register_to_Jura(account_data)
  puts 'Registering ' + account_data[:email_address]
  go_to_Jura
  go_to_registration_page

  under_16 = false

  registration_page = RegistrationPage.new(@browser)
  registration_page.email_address.send_keys(account_data[:email_address])
  registration_page.first_name.send_keys(account_data[:first_name])
  registration_page.last_name.send_keys(account_data[:last_name])
  registration_page.password.send_keys(account_data[:password])
  registration_page.confirm_password.send_keys(account_data[:password])

  sleep(2)
  registration_page.country.send_keys(account_data[:country])
  sleep(1)
  registration_page.countries.each do |country|
    country.click if country.text.eql?(account_data[:country])
  end

  registration_page.day_of_birth.click
  registration_page.days.each do |day|
    day.click if day.text.eql?(account_data[:date_of_birth][:day].to_i.to_s)
  end
  registration_page.month_of_birth.click
  registration_page.months.each do |month|
    month.click if month.text.eql?(account_data[:date_of_birth][:month])
  end
  registration_page.year_of_birth.click
  registration_page.years.each do |year|
    year_of_birth = account_data[:date_of_birth][:year].to_s
    this_year = DateTime.now.strftime "%Y"
    year.click if year.text.eql?(year_of_birth)
    under_16 = true if this_year.to_i - year_of_birth.to_i < 16
  end

  if under_16
    registration_page.parent_email.send_keys(account_data[:parent_email])
    registration_page.confirm_parent_email.send_keys(account_data[:parent_email])
  end

  registration_page.access_code.send_keys(account_data[:registration_code])
  registration_page.register_button.click
  sleep(5)
end

def confirm_under_16_user(parent_username)
  sleep(5) #wait until mail is received, might vary

  @browser.navigate.to('https://mailinator.com/inbox.jsp?to=' + parent_username.split('@')[0])
  wait_for_mailinator_inbox
  mail_inbox_page = MailinatorInboxPage.new(@browser)

  #open email
  mail_inbox_page.emails[0].click
  mail_content_page = MailinatorEmailPage.new(@browser)
  wait_for_email_frame
  email_body = @browser.find_element(:css, 'iframe[name = rendermail]')
  @browser.switch_to.frame(email_body)
  expect(mail_content_page.confirmation_link.displayed?).to eq true

  @browser.navigate.to(mail_content_page.confirmation_link.attribute('href'))
  sleep(5)

  confirmation_registration_page = ConfirmationRegistrationPage.new(@browser)
  expect(confirmation_registration_page.success_message.text.eql?('Success! The account is now registered.'))

  confirmation_registration_page.go_to_login_page_button.click
  sleep(2)
end

def go_to_mailinator(email)
  sleep(5) #wait until mail is received, might vary

  @browser.navigate.to('https://mailinator.com/inbox.jsp?to=' + email.split('@')[0])
  wait_for_mailinator_inbox
  mail_inbox_page = MailinatorInboxPage.new(@browser)
  mail_inbox_page.emails[0].click
end

def add_new_class(page, class_data, grade_setting)
  course_name = class_data[:course_name]
  page.add_class_button.click
  add_class_page = EditClassPage.new(@browser)
  sleep(1)
  add_class_page.class_name_input.send_keys(class_data[:class_name])
  sleep(1)
  add_class_page.courses_select.click
  sleep(1)
  pick_course(add_class_page, course_name)
  sleep(1)
  add_class_page.start_date_button.click
  sleep(1)
  add_class_page.next_month_button.click
  sleep(1)
  add_class_page.start_date.click
  sleep(1)
  add_class_page.end_date_button.click
  sleep(1)
  add_class_page.end_date.click
  sleep(1)
  add_class_page.description.send_keys(class_data[:description])
  sleep(1)
  add_class_page.advanced_settings_button.click
  sleep(1)
  add_class_page.number_of_attempts_button.click
  sleep(1)
  add_class_page.add_number_of_attempts.click
  sleep(1)
  add_class_page.latest_attempts_button.click
  sleep(1)
  add_class_page.pick_last_attempts.click
  sleep(1)
  if grade_setting.to_sym == :percentage
    add_class_page.percentage_radio_button.click
  else
    add_class_page.grade_radio_button.click
    add_class_page.create_class_button.click
    add_class_page.confirm_incomplete_range.click
    return
  end
  sleep(2)
  add_class_page.create_class_button.click
  sleep(2)
end

def go_to_profile_page
  dashboard_page = DashboardPage.new(@browser)
  dashboard_page.header.user_name.click
  sleep(1)
end

def delete_class_on_edit_page(class_name)
  dashboard_page = DashboardPage.new(@browser)
  dashboard_page.header.home_button.click
  dashboard_page.header.menu_button.click
  dashboard_page.header.class_management_button.click
  sleep(3)
  go_to_class_page(class_name)
  sleep(1)

  edit_page = EditClassPage.new(@browser)
  sleep(1)
  edit_page.delete_class_button_edit.click
  sleep(1)
  edit_page.notify_participants_by_email.click
  sleep(1)
  edit_page.confirm_delete_class_button_edit.click
end

def go_to_class_page(class_name)
  classes_page = ClassesPage.new(@browser)
  sleep(1)
  classes_page.search_box.send_keys(class_name)
  sleep(1)
  classes_page.classes.each do |c|
    if c.text.eql?(class_name)
      c.click
      break
    end
  end
end

def join_class_as_student(course_code)
  dashboard_page = DashboardPage.new(@browser)
  dashboard_page.join_class_button.click
  sleep(1)
  dashboard_page.code_input_for_class.send_keys(course_code)
  sleep(1)
  dashboard_page.confirm_code_button_for_class.click
  sleep(2)
  dashboard_page.confirm_code_button_for_course.click
  sleep(2)
end

def lock_unlock_an_activity_of_a_class(class_name, type)
  classes_page = ClassesPage.new(@browser)
  sleep(1)
  classes_page.search_box.send_keys(class_name)
  sleep(1)
  classes_page.lock_unlock_button.click
  sleep(2)
  lock_unlock_page = LockUnlockPage.new(@browser)
  sleep(1)
  lock_unlock_page.lock_unlock_button.click
  sleep(1)
  lock_unlock_page.save_button.click
  sleep(1)
  lock_unlock_page.apply_locks_button.click
  sleep(1)
  lock_unlock_page.locks_applied_button.click
  sleep(1)
end

def get_course_code(class_name)
  go_to_class_page(class_name)
  class_page = ClassPage.new(@browser)
  sleep(1)
  class_page.edit_class_button.click
  sleep(2)
  edit_page = EditClassPage.new(@browser)
  course_code = edit_page.class_password
  sleep(2)
  course_code
end

def set_activity(type, class_name, teacher_data)
  login_to_Jura(teacher_data[:user_name], teacher_data[:password])
  dashboard_page = DashboardPage.new(@browser)
  sleep(1)
  dashboard_page.header.menu_button.click
  dashboard_page.header.class_management_button.click
  sleep(2)

  lock_unlock_an_activity_of_a_class(class_name, type)
  dashboard_page.header.log_out_button.click
end

def join_class_with_new_user(class_data, course_code, new_account_data)
  register_to_Jura(new_account_data)
  login_to_Jura(new_account_data[:email_address], new_account_data[:password])
  sleep(1)
  dashboard_page = DashboardPage.new(@browser)
  # find_course_on_page(dashboard_page, class_data[:course_name])
  join_class_as_student(course_code)
  sleep(3)
  dashboard_page.header.log_out_button.click
end

def go_to_course_index(class_data, new_account_data)
  login_to_Jura(new_account_data[:email_address], new_account_data[:password])
  dashboard_page = DashboardPage.new(@browser)
  sleep(1)
  select_course_from_menu_on(dashboard_page, class_data[:course_name])
  courses_content_page = CoursesContentsPage.new(@browser)
  sleep(1)
  courses_content_page
end

def mark_latest_activity_as_teacher(teacher_data)
  login_to_Jura(teacher_data[:user_name], teacher_data[:password])
  dashboard_page = DashboardPage.new(@browser)

  select_option_from_menu_on(dashboard_page, :marking)
  marking_page = MarkingPage.new(@browser)
  sleep(3)
  marking_page.marking_buttons.last.click
  sleep(3)

  marking_mode_page = MarkingModePage.new(@browser)
  marking_mode_page.score_activity_button.click
  sleep(1)
  marking_mode_page.score_card_modal_score_inputs.each { |i| i.send_keys '1'; sleep(1) }
  sleep(1)
  marking_mode_page.score_card_modal_comments_input.send_keys 'a comment'
  sleep(1)
  marking_mode_page.score_card_modal_submit_and_finish_button.click
  sleep(1)
  marking_mode_page.score_card_modal_submit_button.click
  sleep(1)

  marking_page = MarkingPage.new(@browser)
  marking_page.header.log_out_button.click
  sleep(2)
end

def view_latest_marked_activity_result_as_student(student_data)
  login_to_Jura(student_data[:email_address], student_data[:password])
  dashboard_page = DashboardPage.new(@browser)
  select_option_from_menu_on(dashboard_page, :messages)
  sleep(1)
  messages_page = MessagesPage.new(@browser)
  messages_page.feedback_links.first.click
  sleep(4)
  activity_player_page = ActivityPlayerPage.new(@browser)
  sleep(2)
  activity_player_page.submit_answer_button.click
  sleep(1)
end

def go_to_activity_from(page, course_name, unit, section, index)
  select_course_from_menu_on(page, course_name)
  select_unit_from_course_page(unit)
  select_section_from_unit_page(section)
  select_activity_from_unit_page(index)
end

def submit_incomplete_open_gradable_activity
  activity_player_page = ActivityPlayerPage.new(@browser)
  sleep(2)
  activity_player_page.submit_answer_button.click
  sleep(2)
  activity_player_page.submit_modal_confirm_submit_button.click
  sleep(1)
  activity_player_page.submit_modal_close_button.click
  sleep(1)
  activity_player_page.back_to_unit_button.click
  sleep(1)
end

def send_message_to_class(teacher_data, class_data, message_subject)
  login_to_Jura(teacher_data[:user_name], teacher_data[:password])
  dashboard_page = DashboardPage.new(@browser)
  dashboard_page.header.menu_button.click
  dashboard_page.header.messages_button.click

  message_page = MessagesPage.new(@browser)
  sleep(1)
  message_page.send_message_to_class_button.click
  sleep(1)
  message_page.recipient_plus_button.click
  sleep(1)
  pick_class(message_page, class_data[:class_name])
  sleep(1)
  message_page.subject_input.send_keys('Hello!')
  sleep(1)
  message_page.message_input.send_keys(message_subject)
  sleep(1)
  message_page.send_message_button.click
  sleep(1)
  message_page
end

def reply_message(message_subject)
  message_page = MessagesPage.new(@browser)
  message_page.reply_message_input.send_keys(message_subject)
  sleep(1)
  message_page.reply_message_button.click
  sleep(1)
  message_page.header.log_out_button.click
end