require 'net/http'
require 'uri'
class PostMan

  def self.get_connection(uri, use_ssl = false)
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = use_ssl
    http
  end

  def self.request(method_type, request_data, use_ssl = false)
    return if request_data.empty?

    base_url            = request_data[:base_url]
    resource            = request_data[:resource]
    id                  = request_data[:id]
    query_params        = request_data[:query_params]
    headers             = request_data[:headers]
    body                = request_data[:body]
    number_of_redirects = request_data[:number_of_redirects] || 0

    built_uri = build_uri(base_url, resource, id)

    uri = URI(built_uri)
    connection = get_connection(uri, use_ssl)

    set_query_params(uri, query_params) unless query_params.nil?

    request = setup_request(method_type, uri)
    return if request.nil?

    request.body = body
    add_headers_to_request(request, headers)
    response = connection.request(request)

    return response if number_of_redirects == 0

    self.fetch(response['location'], number_of_redirects)
  end

  private

  def self.build_uri(base_url, resource, id)
    built_uri = id.nil? ? base_url + resource : base_url + resource + '/' + id.to_s
  end

  def self.set_query_params(uri, query_params)
    uri.query = URI.encode_www_form(query_params)

    return uri
  end

  def self.add_headers_to_request(request, headers)
    unless headers.nil?
      headers.each { |header_name, header_value| request[header_name]  = header_value }
    else
      request['Content-Type'] = 'application/json'
    end
    return request
  end

  def self.setup_request(method_type, uri)
    case method_type
      when :get
        request = Net::HTTP::Get.new(uri)
      when :post
        request = Net::HTTP::Post.new(uri)
      when :put
        request = Net::HTTP::Put.new(uri)
      when :delete
        request = Net::HTTP::Delete.new(uri)
      when :options
        request = Net::HTTP::Options.new(uri)
      when :head
        request = Net::HTTP::Head.new(uri)
      when :patch
        request = Net::HTTP::Patch.new(uri)
      else
        return
    end
  end

  def self.fetch(uri_str, limit = 10)
    raise ArgumentError, 'too many HTTP redirects' if limit == 0
    response = Net::HTTP.get_response(URI(uri_str))
    case response
      when Net::HTTPSuccess then
        response
      when Net::HTTPRedirection then
        location = response['location']
        warn "redirected to #{location}"
        self.fetch(location, limit - 1)
      else
        response.value
    end
  end
end