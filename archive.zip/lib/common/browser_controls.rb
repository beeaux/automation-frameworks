require 'selenium-webdriver'
require 'json'
class BrowserControl
  attr_accessor :browser, :selenium, :browser_stack

  def initialize(selenium, browser_stack)
    @selenium = selenium
    @browser_stack = browser_stack
    @browser = nil
  end

  def new_browser(test_browser_name)
    close_existing_browser

    if TestConfig.remote?
      case TestConfig.get_hub
        when :grid
          puts 'running tests on grid'
          set_grid_browser(test_browser_name)
        when :browser_stack
          puts 'running tests on browserstack'
          set_browser_stack_browser
      end
    else
      puts 'running tests local'
      set_local_browser(test_browser_name)
    end
  end

  def close_existing_browser
    unless @browser.nil?
      @browser.quit
    end
  end

  def set_grid_browser(browser_name)
    capabilities = get_grid_capabilities(browser_name)
    @browser = Selenium::WebDriver.for(:remote,
                                       :url => selenium.hub,
                                       :desired_capabilities => capabilities)
  end

  def set_browser_stack_browser
    capabilities = TestConfig.get_browser_stack_capabilities
    puts capabilities
    @browser = Selenium::WebDriver.for(:remote,
                                       :url => browser_stack.hub,
                                       :desired_capabilities => capabilities)
  end

  def set_local_browser(browser_name)
    case browser_name
      when :chrome
        Selenium::WebDriver::Chrome::Service.executable_path = 'bin/chromedriver'
        @browser = Selenium::WebDriver.for browser_name,
                                           :switches => %w[--ignore-certificate-errors
                                                           --disable-popup-blocking
                                                           --disable-translate]
      when :safari
        @browser = Selenium::WebDriver.for browser_name
      when :ie
        # TODO support ie
        Selenium::WebDriver::Chrome::Service.executable_path = 'bin/iedriver'
        @browser = Selenium::WebDriver.for browser_name
      when :firefox
        @browser = Selenium::WebDriver.for browser_name
    end
  end

  def get_grid_capabilities(browser_name)
    case browser_name
      when :chrome
        Selenium::WebDriver::Remote::Capabilities.chrome("chromeOptions" => {"args" => [ "--disable-web-security" ]})
      when :safari
        Selenium::WebDriver::Remote::Capabilities.safari
      when :ie
        Selenium::WebDriver::Remote::Capabilities.ie
      when :firefox
        Selenium::WebDriver::Remote::Capabilities.firefox
    end
  end
end