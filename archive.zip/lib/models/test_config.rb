class TestConfig
  def self.get_environment
    test_env = ENV['bamboo_test_environment'] || ENV['test_environment']
    case test_env
      when 'test'
        return :test
      when 'stage'
        return :stage
      when 'prod'
        return :prod
      else
        return :approval
    end
  end

  def self.get_browser
    test_browser = ENV['test_browser']
    case test_browser
      when 'chrome'
        return :chrome
      when 'ie'
        return :ie
      when 'safari'
        return :safari
      else
        return :firefox
    end
  end

  def self.remote?
    remote = ENV['bamboo_remote'] || ENV['remote']
    case remote
      when 'yes'
        true
      else
        false
    end
  end

  def self.get_hub
    hub = ENV['bamboo_hub'] || ENV['hub']
    case hub
      when 'browserstack'
        return :browser_stack
      else
        return :grid
    end
  end

  def self.get_browser_stack_capabilities
    capabilities = Selenium::WebDriver::Remote::Capabilities.new
    capabilities['project'] = 'JuraAutoUI'
    capabilities['build'] = ENV['bamboo_buildNumber'] || 'no number'
    capabilities['device'] = ENV['bs_device'] || 'null'
    capabilities['browser'] = ENV['bs_browser'] || 'Firefox'
    capabilities['browser_version'] = ENV['bs_browser_version'] || '44.0'
    capabilities['os'] = ENV['bs_os'] || 'Windows'
    capabilities['os_version'] = ENV['bs_os_version'] || '8.1'
    capabilities['resolution'] = ENV['bs_resolution'] || '1024x768'
    capabilities['acceptSslCerts'] = 'true'
    capabilities['browserstack.local'] = 'true'
    capabilities['browserstack.localIdentifier'] = 'BrowserStackLocal'
    capabilities['browserstack.debug'] = true
    capabilities
  end
end