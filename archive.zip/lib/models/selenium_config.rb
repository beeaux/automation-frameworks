class SeleniumConfig
  attr_accessor :selenium_server, :host, :port, :hub
  DEFAULT_HOST = ENV['grid_ip'] || '86.122.168.30'
  DEFAULT_PORT = ENV['grid_port'] || '7055'

  def initialize(host = DEFAULT_HOST, port = DEFAULT_PORT)
    @host = host
    @port = port
    @hub = "http://#{host}:#{port}/wd/hub"
  end

  # maybe we will want to have a local selenium server
  def is_local?
    return (@host == 'localhost' || @host == '127.0.0.1')
  end
end