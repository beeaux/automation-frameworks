class EnvironmentConfig
  @env = {}

  def initialize(environment)
    file = "test_data/#{environment}_environment.yml"
    @generated_email = generate_jura_email
    t = ERB.new(File.read(file))
    @env = YAML.load(t.result(binding).to_s)
  end

  def get_variables
    return @env
  end
end