class BrowserStackConfig
  attr_accessor :user_name, :access_key, :hub

  DEFAULT_USER_NAME = ENV['bs_user_name'] || 'catalinoprisor1'
  DEFAULT_ACCESS_KEY = ENV['bs_password'] || 'f7ebLDyJZPzoRfUkxcB5'

  def initialize(user_name = DEFAULT_USER_NAME, access_key = DEFAULT_ACCESS_KEY)
    @user_name = user_name
    @access_key = access_key
    @hub = "http://#{user_name}:#{access_key}@hub.browserstack.com/wd/hub"
  end
end