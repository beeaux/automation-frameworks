class ActivityPlayerPage < Page

  include Header
  include Footer

  @@header
  def header
    @@header
  end

  @@footer
  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def back_to_unit_button
    browser.find_element(:xpath, '//section/div/div[1]/div/div[3]/button[1]')
  end

  def reset_activity_button
    browser.find_element(:xpath, '//section/div/div[4]/div/div[2]/div/button[2]')
  end

  def submit_answer_button
    browser.find_element(:xpath, '//section/div/div[4]/div/div[2]/div/button[3]')
  end

  def show_correct_answers_button
    browser.find_element(:xpath, '//section/div/div[4]/div/div[2]/div/button[4]')
  end

  def show_my_answers_button
    browser.find_element(:xpath, '//section/div/div[4]/div/div[2]/div/button[5]')
  end

  def submit_modal_try_again_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/div[2]/button[1]')
  end

  def submit_modal_check_answers_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/div[2]/button[2]')
  end

  def submit_modal_confirm_submit_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button[2]')
  end

  def submit_modal_close_button
    browser.find_element(:xpath, '//div[5]/div/div/div[1]/button')
  end

  def activity_score
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/div[1]/div[1]/div/span')
  end

  def necessary_attempts_message
    browser.find_element(:xpath, '//div[5]/div/div/div/div/p')
  end

  def comments_and_scores_modal
    browser.find_element(:xpath, '/html/body/div[5]')
  end

end