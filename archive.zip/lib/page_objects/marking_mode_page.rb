class MarkingModePage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def score_activity_button
    browser.find_element(:xpath, '//section/div/div[4]/div/div/div/button')
  end

  def score_card_modal_score_inputs
    browser.find_elements(:xpath, '//div[5]/div/table/tbody/tr[2]/td[2]/div/div/div[1]/div[1]/ul/li/div/input')
  end

  def score_card_modal_comments_input
    browser.find_element(:xpath, '//div[5]/div/table/tbody/tr[2]/td[2]/div/div/div[1]/div[2]/div/textarea')
  end

  def score_card_modal_submit_and_finish_button
    browser.find_element(:xpath, '//div[5]/div/table/tbody/tr[2]/td[2]/div/div/div[2]/div/button[2]')
  end

  def score_card_modal_submit_button
    browser.find_element(:xpath, '//div[7]/div/div/div[2]/button[2]')
  end
end