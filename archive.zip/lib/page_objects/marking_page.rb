class MarkingPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def marking_buttons
    browser.find_elements(:xpath, '//section/div/div[2]/ul/li[2]/ul/li[6]/button')
  end
end