class MailinatorInboxPage < Page

  def initialize(browser)
    super(browser)
  end

  def inbox
    browser.find_element(:css, '#InboxCtrl')
  end

  def emails
    browser.find_elements(:css, 'a[onclick^=showmail]')
  end

  def email_sender
    browser.find_element(:css, '.from.ng-binding')
  end

  def email_title
    browser.find_element(:css, '.subject.ng-binding')
  end

  def email_time
    browser.find_element(:css, '.time.ng-binding')
  end

  def empty_inbox_message
    browser.find_element(:css, '#noemailmsg')
  end
end