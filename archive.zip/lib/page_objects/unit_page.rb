class UnitPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def sections
    browser.find_elements(:xpath, '//section/div/div[5]/div[2]/div/div/ul/li/div[2]')
  end

  def section_names
    browser.find_elements(:xpath, '//section/div/div[5]/div[2]/div/div/ul/li/div[2]/h4')
  end

  def activities
    browser.find_elements(:xpath, '//section/div/div[6]/div[2]/div/div/ul/li')
  end

  def slide_left_button
    browser.find_element(:xpath, '//section/div/div[5]/div[2]/div/button[1]')
  end

  def slide_right_button
    browser.find_element(:xpath, '//section/div/div[5]/div[2]/div/button[2]')
  end
end