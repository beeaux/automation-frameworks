class MailinatorEmailPage < Page

  def initialize(browser)
    super(browser)
  end

  def delete_button
    browser.find_element(:css, 'button[onclick^=delMsg]')
  end

  def confirmation_link
    browser.find_element(:css, 'a[href*=confirm]')
  end

  def subject
    browser.find_element(:xpath, '//div/div[2]/div/div/div/div[1]/div[1]/div/div/div[1]/div[2]/div/div[1]/div[1]/div[3]/div[2]')
  end
end