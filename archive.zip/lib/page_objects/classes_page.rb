class ClassesPage < Page
  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def classes
    browser.find_elements(:xpath, '//section/div/div[2]/ul/li[2]/ul/li[1]/div/span[1]')
  end

  def search_box
    browser.find_element(:xpath, '//section/div/div[2]/div/div[1]/div/div/input')
  end

  def lock_unlock_button
    browser.find_element(:xpath, '//section/div/div[2]/ul/li[2]/ul/li[5]/a')
  end

  def add_class_button
    browser.find_element(:xpath, '//div[2]/div/div[1]/button[1]')
  end
end