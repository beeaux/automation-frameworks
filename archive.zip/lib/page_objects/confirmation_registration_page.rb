class ConfirmationRegistrationPage < Page

  def initialize(browser)
    super(browser)
  end

  def success_message
    browser.find_element(:xpath, '//section/div/div/div')
  end

  def go_to_login_page_button
    browser.find_element(:css, 'button[type="button"]')
  end
end