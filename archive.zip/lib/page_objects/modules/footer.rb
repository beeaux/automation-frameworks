module Footer

  def self.terms_of_use
    @browser.find_element(:link, 'Terms of Use')
  end

  def self.privacy_policy
    @browser.find_element(:link, 'Privacy Policy')
  end

  def self.cookie_policy
    @browser.find_element(:link, 'Cookie Policy')
  end

  def self.contact_us
    @browser.find_element(:link, 'Contact Us')
  end
end