module Header

  def self.macmillan_logo
    @browser.find_element(:xpath, '//header/nav/a/span[1]')
  end

  def self.home_button
    @browser.find_element(:link, 'Home')
  end

  def self.menu_button
    @browser.find_element(:xpath, '//header/nav/ul/li[2]/div/a/span')
  end

  def self.help_button
    @browser.find_element(:link, 'Help')
  end

  def self.role_button
    @browser.find_element(:xpath, '//header/nav/ul/li[6]/div/div/a')
  end

  def self.user_name
    @browser.find_element(:xpath, '//header/nav/ul/li[5]/a/div')
  end

  def self.log_out_button
    @browser.find_element(:link, 'Log out')
  end

  def self.classes_in_menu
    @browser.find_elements(:xpath, '//header/nav/ul/li[2]/div/div/ul/li/a[contains(., "Classes")]/following-sibling::ul/li')
  end

  def self.courses_in_menu
    @browser.find_elements(:xpath, '//header/nav/ul/li[2]/div/div/ul/li/a[contains(., "Courses")]/following-sibling::ul/li')
  end

  def self.classes_button
    @browser.find_element(:xpath, '//header/nav/ul/li[2]/div/div/ul/li/a/span[contains(., "Classes")]')
  end

  def self.class_management_button
    @browser.find_element(:xpath, '//header/nav/ul/li[2]/div/div/ul/li/a/span[contains(., "Class management")]')
  end

  def self.courses_button
    @browser.find_element(:xpath, '//header/nav/ul/li[2]/div/div/ul/li/a/span[contains(., "Courses")]')
  end

  def self.marking_button
    @browser.find_element(:xpath, '//header/nav/ul/li[2]/div/div/ul/li/a/span[contains(., "Marking")]')
  end

  def self.messages_button
    @browser.find_element(:xpath, '//header/nav/ul/li[2]/div/div/ul/li/a/span[contains(., "Messages")]')
  end

  def self.help_popup
    @browser.find_element(:xpath, '//div[4]/table/tbody/tr[2]/td[2]/div')
  end
end
