class DashboardPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def body
    browser.find_element(:xpath, '//body')
  end

  def active_course
    browser.find_element(:xpath, '//div/div/div/div[2]/div/div/div/header/button[1]')
  end

  def code_input_for_course
    browser.find_element(:xpath, '//div[5]/div/form/div/div[2]/div[1]/div[3]/input')
  end

  def code_input_for_class
    browser.find_element(:xpath, '//div[5]/div/form/div/div[2]/input')
  end

  def confirm_course_activation
    browser.find_element(:xpath, '//div[5]/div/form/div/div[2]/div[2]/button[2]')
  end

  def confirm_code_button_for_course
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button')
  end

  def confirm_code_button_for_class
    browser.find_element(:xpath, '//div[5]/div/form/div/div[2]/button[1]')
  end

  def invalid_code_flash
    browser.find_element(:xpath, '//div[5]/div/form/div/div[2]/div[1]/div[1]')
  end

  def add_class_button
    browser.find_element(:xpath, '//div/div/div/div[2]/div/div/div/header/button[2]')
  end

  def test_class
    browser.find_element(:xpath, '//div/header/nav/ul/li[2]/div/div/ul/li[1]/ul/li[39]/a/span[1]')
  end

  def join_class_button
    browser.find_element(:xpath, '//section/div/div/div/div[2]/div/div/div/div/div/div/div[1]/header/button')
  end

  def next_course_button
    browser.find_element(:xpath, '//section/div/div/div/div[2]/div/div/div/header/div/nav/div/a[2]')
  end

  def course_name
    browser.find_element(:xpath, '//section/div/div/div/div[2]/div/div/div/div/div/div/div[1]/header').text.split("\n")[0..1].join(' ')
  end

  def empty_inbox_notification
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[3]/div/span[2]')
  end

  def messages_list_as_student
    browser.find_elements(:xpath, '//section/div/div/div/aside/div/ul/li')
  end

  def messages_list_as_teacher
    browser.find_elements(:xpath, '//section/div/div/div/aside/div/div[1]/div')
  end

  def message_body
    browser.find_element(:xpath,'//section/div/div/div/aside/div/ul/li[1]/div[4]')
  end

  def message_subject
    browser.find_element(:xpath, '//section/div/div/div/aside/div/ul/li[1]/div[3]')
  end
end