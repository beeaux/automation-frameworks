class RegistrationPage < Page

  def initialize(browser)
    super(browser)
  end

  def email_address
    browser.find_element(:css, 'input[placeholder="Type your Email"]')
  end

  def first_name
    browser.find_element(:css, 'input[placeholder="Type your first name"]')
  end

  def last_name
    browser.find_element(:css, 'input[placeholder="Type your last name"]')
  end

  def password
    browser.find_element(:xpath, '//form/div/div[6]/div[2]/div[1]/div/input[2]')
  end

  def confirm_password
    browser.find_element(:xpath, '//form/div/div[7]/div[2]/div/div/input[2]')
  end

  def country
    browser.find_element(:xpath, '//form/div/div[8]/div[2]/div[1]/div/div[1]/input')
  end

  def countries
    browser.find_elements(:xpath, '//form/div/div[8]/div[2]/div[1]/div/ul/li')
  end

  def day_of_birth
    browser.find_element(:xpath, '//form/div/div[9]/div[2]/div[1]/div/div')
  end

  def days
    browser.find_elements(:xpath, '//form/div/div[9]/div[2]/div[1]/div/ul/li')
  end

  def month_of_birth
    browser.find_element(:xpath, '//form/div/div[9]/div[2]/div[2]/div/div')
  end

  def months
    browser.find_elements(:xpath, '//form/div/div[9]/div[2]/div[2]/div/ul/li')
  end

  def year_of_birth
    browser.find_element(:xpath, '//form/div/div[9]/div[2]/div[3]/div/div')
  end

  def years
    browser.find_elements(:xpath, '//form/div/div[9]/div[2]/div[3]/div/ul/li')
  end

  def access_code
    browser.find_element(:css, 'input[placeholder="Type your access code"]')
  end

  def parent_email
     browser.find_element(:xpath, '//form/div/div[11]/div/input')
  end

  def confirm_parent_email
    browser.find_element(:xpath, '//form/div/div[12]/div/input')
  end

  def register_button
    browser.find_element(:xpath, '//form/div/div[14]/button')
  end

  def go_to_login_page
    browser.find_element(:xpath, '//section/div/div[2]/button')
  end

  def important_information_popup
    browser.find_element(:css, '.popupContent')
  end

  def register_a_new_email_button
    browser.find_element(:xpath, '//form/div/div[5]/button[1]')
  end

  def use_existing_email_button
    browser.find_element(:xpath, '//form/div/div[5]/button[2]')
  end

  def email_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[3]/div[2]/div')
  end

  def first_name_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[4]/div')
  end

  def last_name_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[5]/div[2]/div')
  end

  def password_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[6]/div[2]/div[2]')
  end

  def access_code_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[13]/div/div')
  end

  def country_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[8]/div[2]/div[2]')
  end

  def dob_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[9]/div[2]/div[4]')
  end

  def parent_email_error_message
    browser.find_element(:xpath, '//section/div/form/div/div[11]/div/div')
  end
end