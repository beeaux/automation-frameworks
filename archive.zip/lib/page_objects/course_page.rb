class CoursePage < Page

  include Header
  include Footer

  @@header
  def header
    @@header
  end

  @@footer
  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def units
    browser.find_elements(:xpath, '//section/div/div[4]/ul/li/div[3]/div/a')
  end

  def unit_names
    browser.find_elements(:xpath, '//section/div/div[4]/ul/li/div[3]/p')
  end
end