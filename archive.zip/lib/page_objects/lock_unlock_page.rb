class LockUnlockPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def save_button
    browser.find_element(:xpath, '//section/div/div/div[4]/div[4]/button[1]')
  end

  def lock_unlock_button
    browser.find_element(:xpath, '//section/div/div/div[5]/ul/li[1]/div/a[2]')
  end

  def apply_locks_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button[2]')
  end

  def locks_applied_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button')
  end
end