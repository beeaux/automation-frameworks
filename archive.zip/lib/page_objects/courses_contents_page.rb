class CoursesContentsPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def locked_unit
    browser.find_element(:xpath, '//section/div/div[4]/ul/li[1]/div[1]')
  end
end