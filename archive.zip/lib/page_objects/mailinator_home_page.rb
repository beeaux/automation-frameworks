class MailinatorHomePage < Page

  def initialize(browser)
    super(browser)
  end

  def username
    browser.find_element(:css, '#inboxfield')
  end

  def check_button
    browser.find_element(:css, '.btn-success')
  end
end