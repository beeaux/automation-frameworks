class ClassPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end


  def edit_class_button
    browser.find_element(:xpath, '//div[3]/div/section/div/div/div[1]/div[2]/a[1]')
  end

  def delete_class_button
    browser.find_element(:xpath, '//section/div/div/div[1]/div[2]/a[2]')
  end

  def confirm_delete_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button[2]')
  end

  def class_detail_text
    browser.find_element(:xpath, '//section/div/div/div[1]/div[1]/div/div/label')
  end

  def edit_class_button
    browser.find_element(:xpath, '//div[3]/div/section/div/div/div[1]/div[2]/a[1]')
  end

  def send_message_to_student_button
    browser.find_element(:xpath, '//section/div/div/div[5]/div/div/ul/li[2]/ul/li[1]/a[3]')
  end
end