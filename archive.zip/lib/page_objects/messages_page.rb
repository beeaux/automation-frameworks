class MessagesPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def deleted_folders_button
    browser.find_element(:xpath, '//section/div/div[2]/div[1]/ul/li[2]/a/span[2]')
  end

  def empty_deleted_folder_notification
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[3]/div/span[2]')
  end

  def send_message_to_class_button
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[1]/button[1]')
  end

  def recipient_plus_button
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[2]/div[1]/div[2]/div/div/button')
  end

  def recipients_input
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[2]/div[1]/div[2]/div/div/div[1]/div/input')
  end

  def subject_input
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[2]/div[1]/div[3]/input')
  end

  def message_input
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[2]/div[1]/div[4]/iframe')
  end

  def send_message_button
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[2]/div[2]/button')
  end

  def send_message_notification
    browser.find_element(:xpath, '//section/div/div[1]/span')
  end

  def classes_list
    browser.find_elements(:xpath, '//section/div/div[2]/div[3]/div/div[2]/div[1]/div[2]/div/div/div[2]/ul/li')
  end

  def reply_message_input
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[4]/div[2]/div/div[4]/iframe')
  end

  def reply_message_button
    browser.find_element(:xpath, '//section/div/div[2]/div[3]/div/div[4]/div[2]/div/div[5]/button')
  end

  def messages
    browser.find_elements(:xpath, '//section/div/div[2]/div[2]/div/ul/li')
  end

  def feedback_links
    browser.find_elements(:xpath, '//section/div/div[2]/div[2]/div/ul/li/div[4]/a[1]')
  end
end