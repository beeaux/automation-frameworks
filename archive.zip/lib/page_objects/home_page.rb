class HomePage < Page

  def initialize(browser)
    super(browser)
  end

  def user_name
    browser.find_element(:css, 'input[placeholder="Username"]')
  end

  def user_password
    browser.find_element(:css, 'input[type="password"]')
  end

  def login_button
    browser.find_element(:css, 'button[type="submit"]')
  end

  def register_button
    browser.find_element(:css, 'button[type="button"]')
  end
end