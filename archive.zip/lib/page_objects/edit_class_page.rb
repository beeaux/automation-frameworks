class EditClassPage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def class_name_input
    browser.find_element(:xpath, '//section/div/div/section/form/fieldset[1]/div[1]/div/input')
  end

  def courses_select
    browser.find_element(:xpath, '//section/form/fieldset[1]/div[2]/div/div[1]/div/div')
  end

  def courses
    browser.find_elements(:xpath, '//section/form/fieldset[1]/div[2]/div/div[1]/div/ul/li')
  end

  def start_date_button
    browser.find_element(:xpath, '//section/div/div/section/form/fieldset[1]/div[3]/div[1]/div/input')
  end

  def end_date_button
    browser.find_element(:xpath, '//section/div/div/section/form/fieldset[1]/div[3]/div[1]/div/input')
  end

  def next_month_button
    browser.find_element(:xpath, '//div[4]/div/table/tbody/tr[1]/td/table/tbody/tr/td[3]/div')
  end

  def start_date
    browser.find_element(:xpath, '//div[4]/div/table/tbody/tr[2]/td/table/tbody/tr[5]/td[2]/div')
  end

  def end_date
    browser.find_element(:xpath, '//div[4]/div/table/tbody/tr[2]/td/table/tbody/tr[3]/td[5]/div')
  end

  def description
    browser.find_element(:xpath, '//section/div/div/section/form/fieldset[1]/div[4]/div/textarea')
  end

  def advanced_settings_button
    browser.find_element(:xpath, '//section/form/fieldset[2]/div/div/div[1]/a')
  end

  def number_of_attempts_button
    browser.find_element(:xpath, '//section/form/fieldset[2]/div/div/div[2]/div[1]/div/div/div/div')
  end

  def add_number_of_attempts
    browser.find_element(:xpath, '//section/form/fieldset[2]/div/div/div[2]/div[1]/div/div/div/ul/li[3]')
  end

  def latest_attempts_button
    browser.find_element(:xpath, '//section/form/fieldset[2]/div/div/div[2]/div[2]/div/div/div/div')
  end

  def pick_last_attempts
    browser.find_element(:xpath, '//section/form/fieldset[2]/div/div/div[2]/div[2]/div/div/div/ul/li[2]')
  end

  def percentage_radio_button
    browser.find_element(:xpath, '//section/div/div/section/form/fieldset[2]/div/div/div[2]/div[3]/div/span[1]')
  end

  def grade_radio_button
    browser.find_element(:xpath, '//section/div/div/section/form/fieldset[2]/div/div/div[2]/div[3]/div/span[2]')
  end

  def create_class_button
    browser.find_element(:xpath, '//section/form/fieldset[5]/button')
  end

  def save_button
    browser.find_element(:xpath, '//section/form/fieldset[5]/button')
  end

  def notify_participants_by_email
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/div[2]/span/label')
  end

  def delete_class_button_edit
    browser.find_element(:xpath, '//section/div/div/div[1]/div[2]/a[2]')
  end

  def confirm_delete_class_button_edit
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button[2]')
  end

  def class_password
    browser.find_element(:xpath, '//section/div/div/section/form/fieldset[4]/span').text
  end

  def enter_name_range_notification
    browser.find_element(:xpath, '//section/form/fieldset[3]/div/div/ul/li/ul/li')
  end

  def range_input
    browser.find_element(:xpath, '//section/form/fieldset[3]/div/div/ul/li/div[2]/div/input')
  end

  def name_input
    browser.find_element(:xpath, '//section/form/fieldset[3]/div/div/ul/li/div[1]/input')
  end

  def confirm_incomplete_range
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button[2]')
  end

  def course_name_notification
    browser.find_element(:xpath, '//section/form/div/div')
  end

  def class_name_notification
    browser.find_element(:xpath, '//section/form/fieldset[1]/div[1]/div/div/div')
  end

end