class ProfilePage < Page

  include Header
  include Footer

  @@header

  def header
    @@header
  end

  @@footer

  def footer
    @@footer
  end

  def initialize(browser)
    super(browser)

    @@header = Header
    Header.instance_variable_set(:@browser, browser)
    @@footer = Footer
    Footer.instance_variable_set(:@browser, browser)
  end

  def first_name
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/input[1]')
  end

  def last_name
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/input[2]')
  end

  def email
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/input[3]')
  end

  def username
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/input[4]')
  end

  def day_of_birth
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/div[2]/div/div[1]/div/div')
  end

  def days
    browser.find_elements(:xpath, '//section/div/div[4]/div[2]/div/div/div[2]/div/div[1]/div/ul/li')
  end

  def month_of_birth
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/div[2]/div/div[2]/div/div')
  end

  def months
    browser.find_elements(:xpath, '//section/div/div[4]/div[2]/div/div/div[2]/div/div[2]/div/ul/li')
  end

  def year_of_birth
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/div[2]/div/div[3]/div/div')
  end

  def years
    browser.find_elements(:xpath, '//section/div/div[4]/div[2]/div/div/div[2]/div/div[3]/div/ul/li')
  end

  def invalid_first_name_warning
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/span[1]')
  end

  def invalid_last_name_warning
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/span[2]')
  end

  def invalid_birthday_warning
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/span[3]')
  end

  def invalid_email_warning
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/span[4]')
  end

  def invalid_username_warning
    browser.find_element(:xpath, '//section/div/div[4]/div[2]/div/div/span[5]')
  end

  def password_message
    browser.find_element(:xpath, '//div/div[4]/div[2]/div/div/div[3]/div/div[1]/span')
  end

  def minimum_characters_message
    browser.find_element(:xpath, '//div/div[4]/div[2]/div/div/div[3]/div/div[2]/span')
  end

  def save_profile_button
    browser.find_element(:xpath, '//section/div/div[4]/button')
  end

  def profile_save_success_flash
    browser.find_element(:xpath, '//section/div/div[3]')
  end

  def profile_save_error_flash
    browser.find_element(:xpath, '//section/div/div[2]')
  end

  def confirmation_modal_confirm_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button[2]')
  end

  def confirmation_modal_cancel_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/button[1]')
  end

  def avatar
    browser.find_element(:xpath, '//section/div/div[4]/div[1]/div/div[1]/a/img')
  end

  def avatars
    browser.find_elements(:xpath, '//div[5]/div/div/div[2]/div[2]/div[2]/ul/li/a/img')
  end

  def avatar_select_button
    browser.find_element(:xpath, '//div[5]/div/div/div[2]/div[2]/div[4]')
  end

  def view_subscriptions_button
    browser.find_element(:xpath, '//div/div[4]/div[1]/div/div[2]/div[2]/button')
  end

  def subscriptions
    browser.find_elements(:xpath, '//div[5]/div/div/div[2]/div/div/ul/li[2]/ul')
  end

  def close_subscription_modal_button
    browser.find_element(:xpath, '//div[5]/div/div/div[1]/button')
  end

  def change_password_link
    browser.find_element(:xpath, '//div/div[4]/div[2]/div/div/div[3]/a')
  end

  def current_password_input
    browser.find_element(:xpath, '//div/div[4]/div[2]/div/div/div[3]/div/div[1]/div[2]/div/input[2]')
  end

  def change_password_input
    browser.find_element(:xpath, '//div/div[4]/div[2]/div/div/div[3]/div/div[2]/div[2]/div/input[2]')
  end

  def confirm_password_input
    browser.find_element(:xpath, '//div/div[4]/div[2]/div/div/div[3]/div/div[3]/div[2]/div/input[2]')
  end
end