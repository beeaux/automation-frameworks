require 'selenium-webdriver'
require_relative '../../spec_helper'

describe 'Registration tests : ', :registration do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'registers over 16 student user and then login' do
    student_over_16_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    register_to_Jura(student_over_16_data)
    login_to_Jura(student_over_16_data[:email_address], student_over_16_data[:password])

    expect(@browser.current_url).to match '/dashboard'
  end

  it 'registers under 16 student user and then login' do
    student_under_16_data = generate_new_account_data($env_test_data[:new_under_16_user], :student)
    register_to_Jura(student_under_16_data)
    confirm_under_16_user(student_under_16_data[:parent_email])
    login_to_Jura(student_under_16_data[:email_address], student_under_16_data[:password])

    expect(@browser.current_url).to match '/dashboard'
  end

  it 'registers over 16 teacher user and then login' do
    teacher_over_16_data = generate_new_account_data($env_test_data[:new_over_16_user], :teacher)

    register_to_Jura(teacher_over_16_data)
    login_to_Jura(teacher_over_16_data[:email_address], teacher_over_16_data[:password])

    expect(@browser.current_url).to match '/dashboard'
  end

  it 'displays error when trying to register an existing email' do
    student_over_16_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)

    student_over_16_data[:email_address] = $env_test_data[:users][:student][:user_name]

    register_to_Jura(student_over_16_data)
    registration_page = RegistrationPage.new(@browser)

    expect(registration_page.important_information_popup.displayed?).to eq true
    expect(registration_page.register_a_new_email_button.displayed?).to eq true
    expect(registration_page.use_existing_email_button.displayed?).to eq true
  end

end