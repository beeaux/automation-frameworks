require 'selenium-webdriver'
require_relative '../../spec_helper'

describe 'Redeem code tests : ', :redeem_code do
  before(:each) {
    @browser = Fixtures::Setup.init_browser
    new_account_data = generate_new_account_data($env_test_data[:new_over_16_user], :teacher)

    register_to_Jura(new_account_data)
    login_to_Jura(new_account_data[:email_address], new_account_data[:password])
  }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'redeems code for teacher' do
    dashboard_page = DashboardPage.new(@browser)
    dashboard_page.header.user_name.click
    profile_page = ProfilePage.new(@browser)
    sleep(1)
    profile_page.view_subscriptions_button.click
    sleep(2)

    subscriptions_number = profile_page.subscriptions.size
    profile_page.close_subscription_modal_button.click
    profile_page.header.home_button.click

    dashboard_page = DashboardPage.new(@browser)
    dashboard_page.active_course.click
    sleep(1)
    dashboard_page.code_input_for_course.send_keys($env_test_data[:redeem_code][:all_products])
    sleep(1)
    dashboard_page.confirm_course_activation.click
    sleep(4)
    dashboard_page.header.user_name.click
    profile_page = ProfilePage.new(@browser)
    sleep(2)
    profile_page.view_subscriptions_button.click
    sleep(2)

    expect(profile_page.subscriptions.size == subscriptions_number + 1).to eq true
  end

  it 'validates code redemption for teacher' do
    dashboard_page = DashboardPage.new(@browser)
    dashboard_page.active_course.click
    sleep(1)
    dashboard_page.code_input_for_course.send_keys('invalid code')
    sleep(1)
    dashboard_page.confirm_course_activation.click
    sleep(1)

    expect(dashboard_page.invalid_code_flash.displayed?).to eq true
  end
end
