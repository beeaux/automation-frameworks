require 'selenium-webdriver'
require_relative '../../spec_helper'


describe 'Teacher sends message to students : ', :send_message do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'checks that inbox for teacher is empty when clicking messages button' do
    login_to_Jura($env_test_data[:users][:teacher_runtastic][:user_name], $env_test_data[:users][:teacher_runtastic][:password])
    dashboard_page = DashboardPage.new(@browser)
    sleep(2)
    dashboard_page.header.menu_button.click
    dashboard_page.header.messages_button.click
    sleep(1)

    expect(dashboard_page.empty_inbox_notification.displayed?).to eq true

    dashboard_page.header.log_out_button.click
  end

  it 'checks that inbox for teacher is empty when clicking deleted folder button' do
    login_to_Jura($env_test_data[:users][:teacher_runtastic][:user_name], $env_test_data[:users][:teacher_runtastic][:password])
    dashboard_page = DashboardPage.new(@browser)
    sleep(2)
    dashboard_page.header.menu_button.click
    dashboard_page.header.messages_button.click
    sleep(1)
    messages_page = MessagesPage.new(@browser)
    messages_page.deleted_folders_button.click
    sleep(1)

    expect(messages_page.empty_deleted_folder_notification.displayed?).to eq true

    messages_page.header.log_out_button.click
  end

  it 'teacher sends message to student' do
    new_student_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    class_data = generate_new_class_data
    teacher_data = {:user_name => $env_test_data[:users][:teacher][:user_name],
                    :password => $env_test_data[:users][:teacher][:password]}
    message_subject = 'This is a message!'
    course_code = get_course_code_for_a_new_class(class_data, teacher_data)
    join_class_with_new_user(class_data, course_code, new_student_data)

    message_page = send_message_to_class(teacher_data, class_data, message_subject)

    expect(message_page.send_message_notification.displayed?).to eq true

    message_page.header.log_out_button.click
    login_to_Jura(new_student_data[:email_address], new_student_data[:password])
    dashboard_page = DashboardPage.new(@browser)

    expect(dashboard_page.message_body.text).to include(message_subject)
  end

  it 'student recives message from teacher and replies' do
    new_student_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    class_data = {:class_name => 'Auto' + SecureRandom.random_number(99999).to_s,
                  :description => 'for unlocking',
                  :course_name => $env_test_data[:course_data][:course_name]}
    teacher_data = {:user_name => $env_test_data[:users][:teacher][:user_name],
                    :password => $env_test_data[:users][:teacher][:password]}

    course_code = get_course_code_for_a_new_class(class_data, teacher_data)
    message_subject = 'This is a message!'
    join_class_with_new_user(class_data, course_code, new_student_data)
    send_message_to_class(teacher_data, class_data, message_subject)
    message_page = MessagesPage.new(@browser)
    message_page.header.log_out_button.click
    sleep(2)

    login_to_Jura(new_student_data[:email_address], new_student_data[:password])
    dashboard_page = DashboardPage.new(@browser)
    sleep(1)
    select_message(dashboard_page, message_subject)
    reply_message(message_subject)

    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)

    expect(dashboard_page.messages_list_as_teacher.first.displayed?).to eq true
  end
end