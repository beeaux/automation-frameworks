require_relative '../../spec_helper'

describe 'Reset password tests : ' , category: 'password_reset' do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'should change password successfully' do
    new_password = '123456'

    new_account_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)

    register_to_Jura(new_account_data)
    login_to_Jura(new_account_data[:email_address], new_account_data[:password])
    go_to_profile_page

    profile_page = ProfilePage.new(@browser)
    profile_page.change_password_link.click
    sleep(1)
    profile_page.current_password_input.send_keys(new_account_data[:password])
    profile_page.change_password_input.send_keys(new_password)
    profile_page.confirm_password_input.send_keys(new_password)
    sleep(1)
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true

    profile_page.header.log_out_button.click
    sleep(1)
    login_to_Jura(new_account_data[:email_address], new_password)
    dashboard_page = DashboardPage.new(@browser)

    expect(dashboard_page.header.user_name.displayed?).to eq true
  end

end