require_relative '../../spec_helper'

describe 'Task marking tests : ' , category: 'marking' do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'checks that a student submits an open-gradable activity, then a teacher marks it and then the student can view the results' do
    class_data = {
        :class_name => 'Auto' + SecureRandom.random_number(99999).to_s,
        :description => 'description',
        :course_name => 'BEYOND A2'
    }

    teacher_data = {
        :user_name => $env_test_data[:users][:teacher][:user_name],
        :password => $env_test_data[:users][:teacher][:password]
    }

    course_code = get_course_code_for_a_new_class(class_data, teacher_data)

    student_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)

    register_to_Jura(student_data)
    login_to_Jura(student_data[:email_address], student_data[:password])
    dashboard_page = DashboardPage.new(@browser)
    find_course_on_page(dashboard_page, class_data[:course_name])

    sleep(2)
    join_class_as_student(course_code)
    sleep(2)

    go_to_activity_from(dashboard_page, class_data[:course_name], 'Night and day', 'SPEAKING', 6)

    submit_incomplete_open_gradable_activity

    unit_page = UnitPage.new(@browser)
    unit_page.header.log_out_button.click
    sleep(2)

    mark_latest_activity_as_teacher(teacher_data)

    view_latest_marked_activity_result_as_student(student_data)

    activity_player_page = ActivityPlayerPage.new(@browser)

    expect(activity_player_page.comments_and_scores_modal.displayed?).to eq true
  end
end