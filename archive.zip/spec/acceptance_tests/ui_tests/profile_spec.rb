require_relative '../../spec_helper'

describe 'Profile tests : ' , category: 'profile' do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'warns if the first name field is empty' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.first_name.clear
    profile_page.save_profile_button.click
    sleep(1)

    expect(profile_page.invalid_first_name_warning.displayed?).to eq true
  end

  it 'warns if the last name field is empty' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.last_name.clear
    profile_page.save_profile_button.click
    sleep(1)

    expect(profile_page.invalid_last_name_warning.displayed?).to eq true
  end

  it 'warns if the email field is empty' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.email.clear
    profile_page.save_profile_button.click
    sleep(1)

    expect(profile_page.invalid_email_warning.displayed?).to eq true
  end

  it 'warns if the email address is invalid' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.email.clear
    profile_page.email.send_keys 'invalid@@email.com'
    profile_page.save_profile_button.click
    sleep(1)

    expect(profile_page.invalid_email_warning.displayed?).to eq true
  end

  it 'warns if the username field is empty' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.username.clear
    profile_page.save_profile_button.click
    sleep(1)

    expect(profile_page.invalid_username_warning.displayed?).to eq true
  end

  it 'warns if the username already exists' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.username.clear
    profile_page.username.send_keys 'sic_student2'
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    sleep(1)

    expect(profile_page.profile_save_error_flash.displayed?).to eq true
  end

  it 'warns if the date of birth is invalid' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    select_date_of_birth_on(profile_page, 31, 'February', 1996)

    expect(profile_page.invalid_birthday_warning.displayed?).to eq true
  end

  it 'flashes successfully when updating profile with a valid first name' do
    new_first_name = FFaker::Name.first_name

    login_to_Jura('test.example@mailinator.com', $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.first_name.clear
    profile_page.first_name.send_keys new_first_name
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true
  end

  it 'flashes successfully when updating profile with a valid last name' do
    new_last_name = FFaker::Name.last_name

    login_to_Jura('test.example@mailinator.com', $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.last_name.clear
    profile_page.last_name.send_keys new_last_name
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    sleep(3)
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true
  end

  it 'flashes successfully when updating profile with a valid username' do
    new_username = "#{FFaker::Name.first_name}#{FFaker::Name.last_name}"

    new_account_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)

    register_to_Jura(new_account_data)
    login_to_Jura(new_account_data[:email_address], new_account_data[:password])

    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.username.clear
    profile_page.username.send_keys new_username
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true

    # reverting changes applied on the username field
    profile_page.username.clear
    profile_page.username.send_keys new_account_data[:email_address].to_s
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true
  end

  it 'flashes successfully when updating profile with a valid email' do
    new_email = generate_jura_email()

    new_account_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    register_to_Jura(new_account_data)
    login_to_Jura(new_account_data[:email_address], new_account_data[:password])

    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    profile_page.email.clear
    profile_page.email.send_keys new_email
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true

    # reverting changes applied on the email address field
    profile_page.email.clear
    profile_page.email.send_keys new_account_data[:email_address].to_s
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true
  end

  it 'flashes successfully when updating profile with a valid date of birth' do
    login_to_Jura('test.example@mailinator.com', $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    # save previous date so we can revert future changes
    day = profile_page.day_of_birth.text
    month = profile_page.month_of_birth.text
    year = profile_page.year_of_birth.text

    select_date_of_birth_on(profile_page, 16, 'April', 1989)

    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true

    # reverting changes applied to birth date
    select_date_of_birth_on(profile_page, day, month, year)
    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    wait_for_profile_save_success_flash

    expect(profile_page.profile_save_success_flash.displayed?).to eq true
  end

  it 'changes the avatar' do
    login_to_Jura('test.example@mailinator.com', $env_test_data[:users][:student][:password])
    go_to_profile_page
    profile_page = ProfilePage.new(@browser)
    old_avatar_src = profile_page.avatar.attribute('src')
    profile_page.avatar.click
    sleep(1)
    profile_page.avatars.each { |a| if a.attribute('src') != old_avatar_src and a.displayed? ; a.click ; break; end }
    profile_page.avatar_select_button.click
    sleep(1)
    new_avatar_src = profile_page.avatar.attribute('src')

    expect(new_avatar_src != old_avatar_src).to eq true
  end
end
