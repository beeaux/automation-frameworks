require 'selenium-webdriver'
require_relative '../../spec_helper'

describe 'Edit class tests : ', :edit_class do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'adds a new class' do
    class_data = generate_new_class_data

    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    add_new_class(DashboardPage.new(@browser), class_data, :percentage)
    sleep(3)
    go_to_class_page(class_data[:class_name])
    sleep(1)
    class_page = ClassPage.new(@browser)

    expect(class_page.class_detail_text.displayed?).to eq true
  end

  it 'validates empty data submitting' do
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :class_management)
    sleep(1)

    expect(@browser.current_url).to match($env_test_data[:environment_urls][:site][:class_management])

    class_management_page = ClassesPage.new(@browser)
    class_management_page.add_class_button.click
    edit_class_page = EditClassPage.new(@browser)
    sleep(1)
    edit_class_page.create_class_button.click
    expect(edit_class_page.class_name_notification.displayed?).to eq true
    expect(edit_class_page.course_name_notification.displayed?).to eq true
    expect(edit_class_page.course_name_notification.text.eql?('Please select a course'))
    expect(edit_class_page.class_name_notification.text.eql?('Please enter a class name'))
  end

  it 'validates class editing' do
    class_data = generate_new_class_data
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])

    add_new_class(DashboardPage.new(@browser), class_data, :grade)
    sleep(3)
    go_to_class_page(class_data[:class_name])
    sleep(1)
    class_page = ClassPage.new(@browser)
    class_page.edit_class_button.click
    edit_page = EditClassPage.new(@browser)
    sleep(2)
    edit_page.name_input.send_keys("\b\b")
    sleep(3)

    expect(edit_page.enter_name_range_notification.displayed?).to eq true
    edit_page.range_input.send_keys("\b\b")
    sleep(2)
    expect(edit_page.enter_name_range_notification.displayed?).to eq true
  end

  it 'validates joining a class' do
    new_account_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    class_data = generate_new_class_data
    teacher_data = {:user_name => $env_test_data[:users][:teacher][:user_name],
                    :password => $env_test_data[:users][:teacher][:password]}
    course_code = get_course_code_for_a_new_class(class_data, teacher_data)

    register_to_Jura(new_account_data)
    login_to_Jura(new_account_data[:email_address], new_account_data[:password])
    dashboard_page = DashboardPage.new(@browser)
    join_class_as_student(course_code)

    expect(dashboard_page.join_class_button.displayed?).to eq false
  end

  it 'deletes and checks student email' do
    new_account_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    class_data = {:class_name => 'Auto' + SecureRandom.random_number(99999).to_s, :description => 'description',
                  :course_name => $env_test_data[:course_data][:course_name]}
    teacher_data = {:user_name => $env_test_data[:users][:teacher][:user_name],
                    :password => $env_test_data[:users][:teacher][:password]}

    course_code = get_course_code_for_a_new_class(class_data, teacher_data)

    register_to_Jura(new_account_data)
    login_to_Jura(new_account_data[:email_address], new_account_data[:password])
    sleep(1)
    dashboard_page = DashboardPage.new(@browser)

    join_class_as_student(course_code)
    sleep(3)
    dashboard_page.header.log_out_button.click

    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    sleep(2)
    delete_class_on_edit_page(class_data[:class_name])
    dashboard_page.header.log_out_button.click
    sleep(2)
    go_to_mailinator(new_account_data[:email_address])
    mail_content_page = MailinatorEmailPage.new(@browser)
    wait_for_email_frame

    expect(mail_content_page.subject.text).to match("#{class_data[:class_name]} has been deleted")
  end
end