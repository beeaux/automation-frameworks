require 'selenium-webdriver'
require_relative '../../spec_helper'

describe 'Edit class tests : ', :edit_class do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'edits successfully a class and then removes it' do
    class_data = generate_new_class_data
    new_description = 'new_description'

    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    sleep(2)

    add_new_class(dashboard_page, class_data, :percentage)
    select_class_from_menu_on(dashboard_page, class_data[:class_name])
    sleep(3)
    class_page = ClassPage.new(@browser)
    class_page.edit_class_button.click
    edit_class_page = EditClassPage.new(@browser)
    sleep(1)
    edit_class_page.description.clear
    edit_class_page.description.send_keys(new_description)
    edit_class_page.save_button.click
    sleep(2)
    go_to_class_page(class_data[:class_name])
    sleep(6)
    class_page.edit_class_button.click
    sleep(2)

    expect(edit_class_page.description.attribute('value').to_s.eql?(new_description)).to eq true

    edit_class_page.save_button.click
    go_to_class_page(class_data[:class_name])
    sleep(1)
    class_page.delete_class_button.click
    sleep(1)
    class_page.confirm_delete_button.click
  end
end