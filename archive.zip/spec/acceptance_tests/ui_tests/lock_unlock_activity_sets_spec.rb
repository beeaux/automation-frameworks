require_relative '../../spec_helper'

describe 'Activity lock/unlock tests : ', category: 'activity' do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'locks an activity' do
    new_student_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    class_data = generate_new_class_data
    teacher_data = {:user_name => $env_test_data[:users][:teacher][:user_name],
                    :password => $env_test_data[:users][:teacher][:password]}

    course_code = get_course_code_for_a_new_class(class_data, teacher_data)

    join_class_with_new_user(class_data, course_code, new_student_data)
    set_activity(:lock, class_data[:class_name], teacher_data)

    courses_content_page = go_to_course_index(class_data, new_student_data)

    expect(courses_content_page.locked_unit.displayed?).to eq true
  end

  it 'unlocks an activity' do
    new_student_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)
    class_data = generate_new_class_data
    teacher_data = {:user_name => $env_test_data[:users][:teacher][:user_name],
                    :password => $env_test_data[:users][:teacher][:password]}

    course_code = get_course_code_for_a_new_class(class_data, teacher_data)

    join_class_with_new_user(class_data, course_code, new_student_data)
    set_activity(:lock, class_data[:class_name], teacher_data)
    set_activity(:unlock, class_data[:class_name], teacher_data)

    courses_content_page = go_to_course_index(class_data, new_student_data)

    expect(courses_content_page.locked_unit.displayed?).to eq false
  end
end