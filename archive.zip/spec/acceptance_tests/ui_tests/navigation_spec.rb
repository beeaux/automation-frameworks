require_relative '../../spec_helper'

describe 'Menu navigation tests : ' , category: 'navigation' do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'checks that the macmillan logo takes the logged in user on the home page' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    dashboard_page = DashboardPage.new(@browser)
    dashboard_page.header.user_name.click
    sleep(1)
    profile_page = ProfilePage.new(@browser)
    profile_page.header.macmillan_logo.click
    sleep(1)

    expect(@browser.current_url).to match($env_test_data[:environment_urls][:site][:dashboard])
    dashboard_page.header.log_out_button.click
  end

  it 'checks that the home button takes the logged in user on the home page' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    dashboard_page = DashboardPage.new(@browser)
    dashboard_page.header.user_name.click
    sleep(1)
    profile_page = ProfilePage.new(@browser)
    profile_page.header.home_button.click
    sleep(1)

    expect(@browser.current_url).to match($env_test_data[:environment_urls][:site][:dashboard])
    dashboard_page.header.log_out_button.click
  end

  it 'checks that a popup is displayed after a logged in teacher presses the help button' do
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    dashboard_page.header.help_button.click
    sleep(1)

    expect(dashboard_page.header.help_popup.displayed?).to eq true
    dashboard_page.header.log_out_button.click
  end

  it 'checks that classes are shown after a teacher selects the classes option from the menu' do
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :classes)
    sleep(1)

    expect(dashboard_page.header.classes_in_menu.size != 0).to eq true
    dashboard_page.header.log_out_button.click
  end

  it 'checks that the classes management page is accessed after a teacher selects the class management option from the menu' do
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :class_management)
    sleep(1)

    expect(@browser.current_url).to match($env_test_data[:environment_urls][:site][:class_management])

    class_management = ClassesPage.new(@browser)
    class_management.header.log_out_button.click
  end

  it 'checks that courses are shown after a teacher selects the courses option from the menu' do
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :courses_select)
    sleep(1)

    expect(dashboard_page.header.courses_in_menu.size != 0).to eq true
    dashboard_page.header.log_out_button.click
  end

  it 'checks that the marking page is accessed after a teacher selects the marking option from the menu' do
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :marking)
    sleep(1)

    expect(@browser.current_url).to match($env_test_data[:environment_urls][:site][:marking])

    marking_page = MarkingPage.new(@browser)
    marking_page.header.log_out_button.click
  end

  it 'checks that the messages section is accessed after a teacher selects the messages option from the menu' do
    login_to_Jura($env_test_data[:users][:teacher][:user_name], $env_test_data[:users][:teacher][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :messages)
    sleep(1)

    expect(@browser.current_url).to match($env_test_data[:environment_urls][:site][:messages])

    messages_page = MessagesPage.new(@browser)
    messages_page.header.log_out_button.click
  end

  it 'checks that a popup is displayed after a logged in student presses the help button' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    dashboard_page = DashboardPage.new(@browser)
    dashboard_page.header.help_button.click
    sleep(1)

    expect(dashboard_page.header.help_popup.displayed?).to eq true
    dashboard_page.header.log_out_button.click
  end

  it 'checks that courses are shown after a student selects the courses option from the menu' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :courses_select)
    sleep(1)

    expect(dashboard_page.header.courses_in_menu.size != 0).to eq true
    dashboard_page.header.log_out_button.click
  end

  it 'checks that the messages section is accessed after a student selects the messages option from the menu' do
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    dashboard_page = DashboardPage.new(@browser)
    select_option_from_menu_on(dashboard_page, :messages)
    sleep(1)

    expect(@browser.current_url).to match($env_test_data[:environment_urls][:site][:messages])
    messages_page = MessagesPage.new(@browser)
    messages_page.header.log_out_button.click
  end
end