require_relative '../../spec_helper'

describe 'Reset password validation tests : ' , category: 'password_reset' do
  before(:each) {
    @browser = Fixtures::Setup.init_browser
    login_to_Jura($env_test_data[:users][:student][:user_name], $env_test_data[:users][:student][:password])
    go_to_profile_page
  }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'displays error if current password is not present' do
    new_password = '123456'
    expected_error_message = 'Please enter your current password.'

    profile_page = ProfilePage.new(@browser)
    profile_page.change_password_link.click
    sleep(1)

    profile_page.change_password_input.send_keys(new_password)
    profile_page.confirm_password_input.send_keys(new_password)
    sleep(3)
    profile_page.save_profile_button.click
    sleep(1)

    expect(profile_page.password_message.displayed?).to eq true
    expect(profile_page.password_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays an error to inform that password is less then 6 characters' do
    new_password = '123'
    expected_error_message = 'Please supply a password of at least 6 characters.'

    profile_page = ProfilePage.new(@browser)
    profile_page.change_password_link.click
    sleep(1)

    profile_page.current_password_input.send_keys($env_test_data[:users][:student][:password])
    profile_page.change_password_input.send_keys(new_password)
    profile_page.confirm_password_input.send_keys(new_password)
    sleep(3)

    profile_page.save_profile_button.click
    sleep(1)

    expect(profile_page.minimum_characters_message.displayed?).to eq true
    expect(profile_page.minimum_characters_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays an error to inform that main password is incorrect' do
    incorrect_password = 'incorrect'
    new_password = '123456'
    expected_error_message = 'Password is incorrect. Please check and try again'

    profile_page = ProfilePage.new(@browser)
    profile_page.change_password_link.click
    sleep(1)

    profile_page.current_password_input.send_keys(incorrect_password)
    profile_page.change_password_input.send_keys(new_password)
    profile_page.confirm_password_input.send_keys(new_password)
    sleep(3)

    profile_page.save_profile_button.click
    sleep(1)
    profile_page.confirmation_modal_confirm_button.click
    sleep(3)

    expect(profile_page.password_message.displayed?).to eq true
    expect(profile_page.password_message.text.eql?(expected_error_message)).to eq true
  end

end