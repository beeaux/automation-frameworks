require 'selenium-webdriver'
require_relative '../../spec_helper'


describe 'Fields validation on registration page: ', :registration do
  before(:each) {
    @browser = Fixtures::Setup.init_browser
    go_to_Jura
    go_to_registration_page
  }

  after(:each) { Fixtures::Teardown.close(@browser, self) }


  it 'displays all error messages when invalid data on the registration form' do

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.email_error_message.displayed?).to eq true
    expect(registration_page.first_name_error_message.displayed?).to eq true
    expect(registration_page.last_name_error_message.displayed?).to eq true
    expect(registration_page.password_error_message.displayed?).to eq true
    expect(registration_page.country_error_message.displayed?).to eq true
    expect(registration_page.dob_error_message.displayed?).to eq true
    expect(registration_page.access_code_error_message.displayed?).to eq true
  end

  it 'displays error for no email' do
    expected_error_message = 'Please enter an email address.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.email_error_message.displayed?).to eq true
    expect(registration_page.email_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for invalid email' do
    invalid_email = 'aaaa@@@sdfs.com'
    expected_error_message = 'Please enter a valid email address. Please only use non-accented Latin characters.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.email_address.send_keys(invalid_email)
    registration_page.register_button.click

    expect(registration_page.email_error_message.displayed?).to eq true
    expect(registration_page.email_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no first name' do
    expected_error_message = 'Please enter a first name.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.first_name_error_message.displayed?).to eq true
    expect(registration_page.first_name_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no last name' do
    expected_error_message = 'Please enter a last name.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.last_name_error_message.displayed?).to eq true
    expect(registration_page.last_name_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no password' do
    expected_error_message = 'Please enter a password.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.password_error_message.displayed?).to eq true
    expect(registration_page.password_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no matching passwords' do
    expected_error_message = 'Passwords do not match.'
    password = 'password'

    registration_page = RegistrationPage.new(@browser)
    registration_page.password.send_keys(password)
    registration_page.confirm_password.send_keys(password.reverse)
    registration_page.register_button.click

    expect(registration_page.password_error_message.displayed?).to eq true
    expect(registration_page.password_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no country' do
    expected_error_message = 'Please select a country.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.country_error_message.displayed?).to eq true
    expect(registration_page.country_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no date of birth' do
    expected_error_message = 'Please select your date of birth.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.dob_error_message.displayed?).to eq true
    expect(registration_page.dob_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no access code' do
    expected_error_message = 'Please enter an access code. This is printed in your book or your leaflet.'

    registration_page = RegistrationPage.new(@browser)
    registration_page.register_button.click

    expect(registration_page.access_code_error_message.displayed?).to eq true
    expect(registration_page.access_code_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for no parent email' do
    expected_error_message = 'Please enter a valid parent/guardian email address.'

    registration_page = RegistrationPage.new(@browser)
    select_date_of_birth_on(registration_page, 11, 'March', (DateTime.now.year - 5).to_s)
    registration_page.register_button.click

    expect(registration_page.parent_email_error_message.displayed?).to eq true
    expect(registration_page.parent_email_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for non matching parent emails' do
    expected_error_message = 'The parent/guardian email addresses don\'t match. Please re-type the email addresses.'
    email = 'aaa@aaa.com'

    registration_page = RegistrationPage.new(@browser)
    select_date_of_birth_on(registration_page, 11, 'March', (DateTime.now.year - 5).to_s)
    registration_page.parent_email.send_keys(email)
    registration_page.confirm_parent_email.send_keys(email.reverse)
    registration_page.register_button.click

    expect(registration_page.parent_email_error_message.displayed?).to eq true
    expect(registration_page.parent_email_error_message.text.eql?(expected_error_message)).to eq true
  end

  it 'displays error for invalid parent emails' do
    expected_error_message = 'The parent/guardian email address is not valid. Please only use non-accented Latin characters.'
    email = 'aaa@@'

    registration_page = RegistrationPage.new(@browser)
    select_date_of_birth_on(registration_page, 11, 'March', (DateTime.now.year - 5).to_s)
    registration_page.parent_email.send_keys(email)
    registration_page.confirm_parent_email.send_keys(email)

    registration_page.register_button.click

    expect(registration_page.parent_email_error_message.displayed?).to eq true
    expect(registration_page.parent_email_error_message.text.eql?(expected_error_message)).to eq true
  end

end
