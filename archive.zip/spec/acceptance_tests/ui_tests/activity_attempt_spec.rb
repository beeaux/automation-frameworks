require_relative '../../spec_helper'

describe 'Activity attempt tests : ', category: 'activity' do
  before(:each) { @browser = Fixtures::Setup.init_browser }

  after(:each) { Fixtures::Teardown.close(@browser, self) }

  it 'attempts an activity a sufficient number of times so that the student can see the correct answers or his answers' do
    student_data = generate_new_account_data($env_test_data[:new_over_16_user], :student)

    register_to_Jura(student_data)
    login_to_Jura(student_data[:email_address], student_data[:password])

    dashboard_page = DashboardPage.new(@browser)
    select_course_from_menu_on(dashboard_page, 'BEYOND A1+')

    course_page = CoursePage.new(@browser)
    course_page.units.first.click
    sleep(2)
    unit_page = UnitPage.new(@browser)
    unit_page.sections.first.click
    sleep(2)
    unit_page.activities.first.click
    sleep(3)
    activity_player_page = ActivityPlayerPage.new(@browser)
    activity_player_page.submit_answer_button.click
    sleep(1)

    loop do
      break unless activity_player_page.necessary_attempts_message.displayed?
      activity_player_page.submit_modal_try_again_button.click
      activity_player_page.submit_answer_button.click
      sleep(2)
      expect(activity_player_page.activity_score.text.to_i).to eq 0
    end

    activity_player_page.submit_modal_check_answers_button.click
    sleep(1)

    expect(activity_player_page.show_correct_answers_button.displayed?).to eq true
    expect(activity_player_page.show_correct_answers_button.click).to eq 'ok'
    sleep(1)
    expect(activity_player_page.show_my_answers_button.displayed?).to eq true
    expect(activity_player_page.show_my_answers_button.click).to eq 'ok'
  end
end