require 'ffaker'

describe 'Faker tests : ', :faker_tests do

  it 'should return a new hash with values' do
    generated_hash = Hash.new

    generated_hash[:name] = FFaker::Name.name
    generated_hash[:city] = FFaker::Address.city
    generated_hash[:street_name] = FFaker::Address.street_name
    generated_hash[:country] = FFaker::Address.country

    expect(generated_hash.each_value.nil?).to eq false
  end
end