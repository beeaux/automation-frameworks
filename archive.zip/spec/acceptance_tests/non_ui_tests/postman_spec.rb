require_relative '../../spec_helper'
require 'pry'
require 'json'

describe 'PostMan tests : ', :non_ui_tests do
  it 'should delete the targeted id' do
    expected_code = '200'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '/posts',
      id: 1,
      query_params: nil,
      body: nil,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:delete, request_data)

    expect(response.code).to eq(expected_code)
  end

  it 'should return 200 when resource exists' do
    expected_status = '200'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '/posts',
      id: 1,
      query_params: nil,
      body: nil,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:put, request_data)

    expect(response.code).to eq(expected_status)
  end

  it 'should get the targeted id' do
    expected_code = '200'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '/posts',
      id: 1,
      query_params: nil,
      body: nil,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:get, request_data)

    expect(response.code).to eq(expected_code)
  end

  it 'should get the targeted id filtered by a list of query params' do
    expected_code = '200'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '/comments',
      id: 1,
      query_params: {"postId" => 1, "email" => "Hayden_Olson@marianna.me"},
      body: nil,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:get, request_data)

    expect(response.code).to eq(expected_code)
  end

  it 'should return 200 when using options verb' do
    expected_code = '200'
    request_data = {
      base_url: 'http://www.mocky.io',
      resource: '/v2',
      id: '55d6df70c97bff6b01a685bd',
      query_params: nil,
      body: nil,
      headers: {"Content-Type" => "text/html"},
      number_of_redirects: 0
    }

    response = PostMan.request(:options, request_data)

    expect(response.code).to eq(expected_code)
  end

  it 'should return success for getting the headers when sending a head request' do
    expected_code = '200'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '',
      id: nil,
      query_params: nil,
      body: nil,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:head, request_data)

    expect(response.code).to eq(expected_code)
  end

  it 'should not return the body when sending a head request' do
    expected_code = '200'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '',
      id: nil,
      query_params: nil,
      body: nil,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:head, request_data)

    expect(response.body).to eq nil
  end

  it 'should return 201 for creating a new resource' do
    expected_code = '201'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '/posts',
      id: nil,
      query_params: nil,
      body: {userId: 11, id: 101, title: 'test title', body: 'test body'}.to_json,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:post, request_data)

    expect(response.code).to eq(expected_code)
  end

  it 'should partially update the resource' do
    expected_status = '200'
    request_data = {
      base_url: 'http://jsonplaceholder.typicode.com',
      resource: '/posts',
      id: 1,
      query_params: nil,
      body: { title: 'sunt aut facere repellat provident occaecati excepturi optio reprehenderit'}.to_json,
      headers: nil,
      number_of_redirects: 0
    }

    response = PostMan.request(:patch, request_data)

    expect(response.code).to eq(expected_status)
  end
end