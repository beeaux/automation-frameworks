task :default => [:test]

task :test do
  command = "rspec spec -f JUnit -o results.xml"
  exec(command)
end